# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution. 

## Credential Values

- Android keystore password: 661938166096445f8631338c6b9527b1
- Android key alias: QGFobWFkMTctZmUvc2hpbGF1
- Android key password: 8933e5199fa941dea8c683594079cd0f
      