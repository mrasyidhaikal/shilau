const DATA = [
  {
    id: '0001123333331231',
    title: 'PBL Shilau',
    status: 'lihat tracking',
    date: '20 Mar 2021',
  },
  {
    id: '0001123333331232',
    title: 'CHLOE',
    status: 'belum check out',
    date: '17 Mar 2021',
  },
  {
    id: '0001123333331233',
    title: 'Web Poltek',
    status: 'selesai',
    date: '18 Mar 2020',
  },
  {
    id: '0001123333331234',
    title: 'Project 1',
    status: 'lihat tracking',
    date: '1 Apr 2021',
  },
  {
    id: '0001123333331235',
    title: 'Project 2',
    status: 'belum check out',
    date: '5 Apr 2021',
  },
  {
    id: '0001123333331236',
    title: 'Project 3',
    status: 'selesai',
    date: '7 Apr 2021',
  },
  {
    id: '0001123333331237',
    title: 'Project 4',
    status: 'selesai',
    date: '7 Apr 2021',
  },
  {
    id: '0001123333331238',
    title: 'Project 5',
    status: 'lihat tracking',
    date: '20 Apr 2021',
  },
]

export default DATA
